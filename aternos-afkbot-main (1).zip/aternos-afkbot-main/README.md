# Aternos AFKBot ✨
This afk bot will keep your aternos server alive 24/7

Simple for keeping an aternos server alive, or trying to get an AFKBot on your server. 
IT DOESN'T HAVE TO BE AN ATERNOS SERVER too! It can be any server as long as it's cracked. Uses the mineflayer tool created by MannuG. This bot unlike any other will move around, keeping the server alive. I recommend putting the bot in a bedrock casing to keep it from going everywhere and dying.

Mainly Supports Minecraft version 1.8, 1.9, 1.10, 1.11, 1.12, 1.13, 1.14, 1.15 and 1.16.

# Requirements 🎒
What You'll need

1. You will need a Heroku account, just a simple free one will do. Sign up at: https://signup.heroku.com/login
2. An Aternos server, Any Minecraft Server will do, make sure it has "online-mode"set to false.
3. A Github account (obviously)
5. That's all you need!

# Setup ⚙
1. Fork this repository, or clone the repository and make it your own
2. Change the config file to your own aternos server
3. Go to https://dashboard.heroku.com/ and create a new application
4. Once you've created your application, simply go to the "Deploy" section and select the repository that you forked
5. Select master and click on "Deploy Branch"
6. Click on the "More" button at the top and click "Restart all Dynos"
7. Done! Enjoy your free 24/7 aternos server

# CAUTION ⚠
Aternos might detect your behavior and they might delete your account!

You are responsible for your own actions. I do not recommend doing this on your main aternos server!
